#include "../inc/msg.h"

typedef int make_iso_compilers_happy2;