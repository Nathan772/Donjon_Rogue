#include "../inc/musique.h"


/*lance le son lié à la découverte d'un coffre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void treasure_sound(int off){
	MLV_Sound *sound;
	if(off ==0)
		return;
	

	sound = MLV_load_sound("Musique/Pieces.ogg");

	MLV_play_sound(sound, 50);
}

/* lance le bruit de pas lié aux mouvements du héros*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void walk_sound(int off){
	MLV_Sound *sound;
	if(off == 0)
		return;
	

	sound = MLV_load_sound("Musique/Marche.ogg");

	MLV_play_sound(sound, 50);
}

/* lance le son lié à l'apparition d'un monstre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void monster_sound(int off){
	MLV_Sound *sound;
	if(off == 0)
		return;
	

	sound = MLV_load_sound("Musique/Monstre.ogg");

	MLV_play_sound(sound, 50);
}

/* lance le son lors d'une attaque*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_sound(int off){
	MLV_Sound *sound;
	if(off == 0)
		return;
	

	sound = MLV_load_sound("Musique/Sword_fight.ogg");

	MLV_play_sound(sound, 50);
}

/* lance la musique de combat*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_music(int off){
	MLV_Music *music;
	if(off == 0)
		return;

	monster_sound(off);

	music = MLV_load_music("Musique/Heros.mp3");
	MLV_play_music(music, 5, -1);
}

/* coupe la musique*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void music_off(){
	MLV_Music *music;
	music = MLV_load_music("Musique/Heros.mp3");
	MLV_free_music(music);
}

/* coupe la musique*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void sound_off(){
	MLV_Sound *sound;


	sound = MLV_load_sound("Musique/Marche.ogg");
	MLV_free_sound(sound);

	sound = MLV_load_sound("Musique/Monstre.ogg");
	MLV_free_sound(sound);


	sound = MLV_load_sound("Musique/Pieces.ogg");
	MLV_free_sound(sound);

	sound = MLV_load_sound("Musique/Sword_fight.ogg");
	MLV_free_sound(sound);
}

/* lance toutes les musiques*/
void launch_musics() {
	/*fight_music(1);*/

}
/* lance tous les sons*/
void launch_sounds(){
	/*treasure_sound(1);
	walk_sound(1);
	monster_sound(1);*/

}
/* arrête les musiques*/
void stop_music(){
	MLV_stop_music();
}

/* arrête les sons*/
void stop_sound(){
	MLV_stop_all_sounds();
}

