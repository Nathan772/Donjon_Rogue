#ifndef __OBJET__
#define __OBJET__

	#include <stdlib.h>
	#include <stdbool.h>
	#include <stdio.h>




#endif

