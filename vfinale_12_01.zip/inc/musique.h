#ifndef __MUSIQUE__
#define __MUSIQUE__

#include <MLV/MLV_all.h>

/*lance le son lié à la découverte d'un coffre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void treasure_sound(int off);

/* lance le bruit de pas lié aux mouvements du héros*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void walk_sound(int off);
/* lance le son lié à l'apparition d'un monstre*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void monster_sound(int off);

/* lance le son lors d'une attaque*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_sound(int off);

/* lance la musique de combat*/
/* si la variable vaut true (0) on coupe le son sinon on laisse*/
void fight_music(int off);

/* coupe la musique*/
void music_off();
/* coupe la musique*/
void sound_off();


/* lance toutes les musiques*/
void launch_musics();
/* lance tous les sons*/
void launch_sounds();




/* arrête les musiques*/
void stop_music();

/* arrête les sons*/
void stop_sound();

#endif