#ifndef __BOOLEAN__
#define __BOOLEAN__

	typedef enum boolean{
			TRUE,
			FALSE
		}Boolean;

#endif