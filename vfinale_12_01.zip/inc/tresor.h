#ifndef __TRESOR__
#define __TRESOR__

	#include "equipement.h"
	#include "potion.h"
	#include "coordonnees.h"
	#include "boolean.h"

	union Item {
		Equipement eq;
		Potion pot;
	};



	/*Représente le type d'une case*/
	typedef enum treasuretype {
		EQUIPEMENT,
		POTION

	} Treasuretype;

	typedef struct tresor {
		union Item item;
		Treasuretype type_tresor;
	} Treasure;

	Treasure generate_treasure(int etage);


	/*Les trésors contiennent des objets 

	- potion
	- armures
	- baguettes magique 



	*/


#endif
