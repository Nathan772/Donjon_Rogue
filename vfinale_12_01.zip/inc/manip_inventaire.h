#ifndef __MANIP_INVENTAIRE__
#define __MANIP_INVENTAIRE__

#include <MLV/MLV_all.h>

#include "equipement.h"
#include "potion.h"
#include "perso.h"
#include "terrain.h"
#include "tresor.h"
#include "boolean.h"
#include "musique.h"

#endif