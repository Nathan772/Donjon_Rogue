#ifndef __objet__
#define __objet__
#include <stdbool.h>
typedef enum {soin, magie, regeneration, precision,
apprentissage} typePotion ;
typedef struct {
	typePotion type;
	int hp ;
	int mp ;
	/* permet de savoir si l'objet fonctionne en pourcentage ou en augmentation d'une valeur des hp/mp*/
	bool pourcentage;
	/* correspond au pourcentage d'augmentation de coup critique avec cette potion*/
	int critique;
	/* correspond au pourcentage d'augmentation d'exp avec cette potion*/
	int exp;
	/* correspond au nombre de tour où la potion est effective*/
	int tour;
} Potion;
#endif