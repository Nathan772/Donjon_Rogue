#ifndef __equipement__
#define __equipement__

typedef enum {bouclier, arme, baguette, precision,
apprentissage} typeEquipement ;
typedef enum {mauvais, moyen, bon, excellent,
rare} typeQualite ;

typedef struct {
	typeEquipement type;
	int atk ;
	int def ;
	int inte;
	typeQualite qual;
} equipement;
#endif