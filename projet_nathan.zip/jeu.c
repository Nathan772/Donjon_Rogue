#ifndef
#include "terrain.h"
#include "perso.h"
#include "sauvegarde.h"
#include "monstre.h"
#include "msg.h"
#include "graphique.h"
#endif