#ifndef __perso__
#define __perso__
#include "equipement.h"
#include "objet.h"

typedef struct {
	int hp;
	int mp;
	int atk;
	int inte;
	int def;
	int exp;
	int lv;
	
} Perso ;
#endif