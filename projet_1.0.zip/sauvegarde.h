#ifndef __sauvegarde__
#define __sauvegarde__
#include "terrain.h"
#include "tresor.h"
#include "perso.h"
#include "monstre.h"
#endif