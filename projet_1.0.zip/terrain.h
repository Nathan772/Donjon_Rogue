#ifndef __terrain__
#define __terrain__
#include "tresor.h"
#include "perso.h"
#endif