#ifndef __graphique__
#define __graphique__
#include <MLV/MLV_all.h>
#include "equipement.h"
#include "objet.h"
#include "perso.h"
#include "terrain.h"
#include "tresor.h"

#endif