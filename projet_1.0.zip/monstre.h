#ifndef __monstre__
#define __monstre__
#endif