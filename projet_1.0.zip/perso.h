#ifndef __perso__
#define __perso__
#include "equipement.h"
#include "objet.h"
#endif